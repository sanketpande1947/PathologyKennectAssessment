package com.pathology.pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage {
    private WebDriver driver;

    private By Header = By.xpath("//div[text()='Dashboard']");
    private By PatientList = By.xpath("//li[@class='MuiListItem-container']/div/div/span");

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public String isDashBoardVisible() {
    	
    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(Header));
        
        return driver.findElement(Header).getText();
    }
    
    public void checkPatientNameOnDashboard() throws InterruptedException {
    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(PatientList));
        
    	List<WebElement> patients = driver.findElements(PatientList);
    	boolean found = false;
        for (WebElement patient : patients) {
        	String name = patient.getText();
            if (name.contains("sanket")) {
                found = true;
                break;
            }
        }
        
        if(found) {
        	System.out.println("Patient name has been reflected in the list of todos on the home page.");
        }else {
        	System.out.println("Patient name has not been reflected in the list of todos on the home page.");
        }
        
        
    }
    
    


}

