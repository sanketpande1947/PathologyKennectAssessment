package com.pathology.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PatientsPage {
	
	private WebDriver driver;
	private By name = By.name("name");
	private By email = By.name("email");
	private By phoneNum = By.name("phone");
	private By generateDetailsBtn = By.xpath("//span[text()='Add Tests']/ancestor::div[3] /following-sibling::div //button[2]/span");
	
	private By height = By.name("height");
	private By weight = By.name("weight");
	private By genderDropDown = By.id("mui-component-select-gender");
	private By genderSelectionBtn = By.xpath("//li[text()='Male']");
	private By age = By.name("age");
	private By addTestsBtn = By.xpath("//span[text()='Add Tests']/ancestor::div[3] /following-sibling::div //button[2]/span[1]");
	
	
	public PatientsPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public void fillPatientDetails(String patientname, String patientemail, String num) throws InterruptedException {
		driver.findElement(name).sendKeys(patientname);
		driver.findElement(email).sendKeys(patientemail);
		driver.findElement(phoneNum).sendKeys(num);
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
        
        Thread.sleep(3000);
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(generateDetailsBtn));
        
		driver.findElement(generateDetailsBtn).click();	
	}
	
	
	public void fillPatientSecondaryDetails(String patientheight, String patientweight, String patientage) throws InterruptedException {
		driver.findElement(height).sendKeys(patientheight);
		driver.findElement(weight).sendKeys(patientweight);
		driver.findElement(genderDropDown).click();
		driver.findElement(genderSelectionBtn).click();
		driver.findElement(age).sendKeys(patientage);
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
        
        Thread.sleep(3000);
        
		driver.findElement(addTestsBtn).click();
	}
	

}
