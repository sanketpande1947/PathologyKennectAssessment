package com.pathology.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class TestsPage {
	
	private WebDriver driver;
	
	private By navigateToTestPage = By.xpath("//span[text()='Tests']/parent::div");
	private By addBtn = By.xpath("//div[text()='Tests']//following-sibling::a[2]/child::button");
	


    public TestsPage(WebDriver driver) {
        this.driver = driver;
    }
    
    public void addPatientTest() {
        driver.findElement(addBtn).click();
    }
    
    public void navigateToTestPage() {
        driver.findElement(navigateToTestPage).click();
    }
    

    
}
