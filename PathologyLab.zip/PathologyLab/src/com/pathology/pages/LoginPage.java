package com.pathology.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {
    private WebDriver driver;

    private By usernameField = By.name("email");
    private By passwordField = By.name("password");
    private By loginButton = By.xpath("//span[text()='Login']/parent::button");


    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public void login(String username, String password) {
    	
    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(usernameField));
    	
        driver.findElement(usernameField).sendKeys(username);
        driver.findElement(passwordField).sendKeys(password);
        driver.findElement(loginButton).click();
        
        
    }
}
