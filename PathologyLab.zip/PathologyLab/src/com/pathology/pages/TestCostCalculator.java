package com.pathology.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TestCostCalculator {
	
	private WebDriver driver;

	private By DiscountBtn = By.xpath("//label[text()='Discount']//following-sibling::div//child::div");
	private By selectdiscount = By.xpath("//li[@data-value='5']");	
	private By selectLabsDropdownBtn = By.xpath("//label[@id='patient-tests-labs-label']//following-sibling::div//child::div//button[2]");	
	private By addEquipmentBtn = By.xpath("//span[text()='add_box']");	
	private By equipmentNameDropDown = By.xpath("//div[@aria-label='Eqipment Name']");
	private By equipmentName = By.xpath("//li[text()='injection']");
	private By checkBtn = By.xpath("//span[text()='check']");	
	private By addPatientbtn = By.xpath("//span[text()='Add Patient']");	
	private By addTestForPatientBtn = By.xpath("//button[@title='Open']");	
	private By subtotal = By.xpath("//div[text()='Subtotal']//following-sibling::div");
	private By Total = By.xpath("//div[text()='Total']//following-sibling::div");
	
	public static String actualSubTotal;
	public static String actualTotal;

	public TestCostCalculator(WebDriver driver) {
		this.driver = driver;
	}
	
	
	public void addTestsAndEquipment() throws InterruptedException{
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0, 0);");
		
		Thread.sleep(3000);      //This is not standard way to use Thread.sleep but due to application constraint in some cases I have used
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(addTestForPatientBtn));
        
		driver.findElement(addTestForPatientBtn).click();
		
		Thread.sleep(3000);
		
		Actions ac = new Actions(driver);
		ac.sendKeys(Keys.ARROW_DOWN).perform();
		ac.sendKeys(Keys.ARROW_DOWN).perform();
		ac.sendKeys(Keys.ARROW_DOWN).perform();
		ac.sendKeys(Keys.ARROW_DOWN).perform();
		ac.sendKeys(Keys.ENTER).perform();
		
		driver.findElement(DiscountBtn).click();
		driver.findElement(selectdiscount).click();
	
		driver.findElement(selectLabsDropdownBtn).click();
		
		Thread.sleep(3000);
		
		ac.sendKeys(Keys.ARROW_DOWN).perform();
		ac.sendKeys(Keys.ENTER).perform();
		
		js.executeScript("window.scrollTo(0, document.body.scrollHeight / 2);");
        
        Thread.sleep(3000);
		
		driver.findElement(addEquipmentBtn).click();
		driver.findElement(equipmentNameDropDown).click();
		driver.findElement(equipmentName).click();
		
		
		driver.findElement(checkBtn).click();
		
		js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
		
		driver.findElement(addPatientbtn).click();		
	}
	
	public void validateBloodTestCalculator() throws InterruptedException {
		
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
        
        Thread.sleep(4000);
        
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(addTestForPatientBtn));
        
		driver.findElement(addTestForPatientBtn).click();
		
		Thread.sleep(3000);
		
		Actions ac = new Actions(driver);
		ac.sendKeys(Keys.ARROW_DOWN).perform();
		ac.sendKeys(Keys.ARROW_DOWN).perform();
		ac.sendKeys(Keys.ARROW_DOWN).perform();
		ac.sendKeys(Keys.ARROW_DOWN).perform();
		ac.sendKeys(Keys.ENTER).perform();
		
		driver.findElement(DiscountBtn).click();
		driver.findElement(selectdiscount).click();
		
		// to find subtotal
		String subTotal = driver.findElement(subtotal).getText();
		String [] subTotalBreaks = subTotal.split(" ");
		
		actualSubTotal = subTotalBreaks[0];
		System.out.println(actualSubTotal);
		
		// to find Total
		String Total1 = driver.findElement(Total).getText();
		String [] TotalBreaks = Total1.split(" ");
		
		actualTotal = TotalBreaks[0];
		System.out.println(actualTotal);
		
		js.executeScript("window.scrollTo(0, 0);");
		
		
		
		
		
	}

}
