package com.pathology.tests;

import com.pathology.pages.HomePage;
import com.pathology.pages.LoginPage;
import com.pathology.pages.TestCostCalculator;

import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;

import org.testng.Assert;

public class CostCalculatorTest extends BaseTest {
	
    @Test
    public void testCostCalculation() throws InterruptedException {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("test@kennect.io", "Qwerty@1234");

        HomePage homePage = new HomePage(driver);
        Assert.assertEquals(homePage.isDashBoardVisible(), "Dashboard");       

        TestCostCalculator calculatorPage = new TestCostCalculator(driver);
        calculatorPage.validateBloodTestCalculator();
        
        Assert.assertEquals(calculatorPage.actualSubTotal , "900");  
        Assert.assertEquals(calculatorPage.actualTotal , "855");

    }
}
