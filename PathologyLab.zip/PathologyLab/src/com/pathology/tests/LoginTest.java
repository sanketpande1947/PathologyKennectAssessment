package com.pathology.tests;

import com.pathology.pages.LoginPage;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest {
    @Test
    public void testLogin() {
    	LoginPage loginpage  = new LoginPage(driver);
    	loginpage.login("test@kennect.io", "Qwerty@1234");

    }
}
