package com.pathology.tests;

import com.pathology.pages.HomePage;
import com.pathology.pages.LoginPage;
import com.pathology.pages.PatientsPage;
import com.pathology.pages.TestCostCalculator;
import com.pathology.pages.TestsPage;

import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;

import org.testng.Assert;

public class PatientModuleTest extends BaseTest {
	
    @Test
    public void validatePatientMoudule() throws InterruptedException {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("test@kennect.io", "Qwerty@1234");

        HomePage homePage = new HomePage(driver);
        Assert.assertEquals(homePage.isDashBoardVisible(), "Dashboard");       

        TestsPage test = new TestsPage(driver);
        test.navigateToTestPage();
        test.addPatientTest();
        
        PatientsPage patient = new PatientsPage(driver);
        patient.fillPatientDetails("sanket", "skpandey@gmail.com", "9123456789");
        patient.fillPatientSecondaryDetails("140", "45", "28");
        
        TestCostCalculator test1 = new TestCostCalculator(driver);
        test1.addTestsAndEquipment();
        
        homePage.checkPatientNameOnDashboard();
        

    }
}
