package com.pathology.tests;

import com.pathology.pages.HomePage;
import com.pathology.pages.LoginPage;
import org.testng.annotations.Test;

import static org.testng.Assert.assertTrue;

import org.testng.Assert;

public class HomePageTest extends BaseTest {
	
	@Test
    public void isDashBoardVisibleCorect() throws InterruptedException {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("test@kennect.io", "Qwerty@1234");

        HomePage homePage = new HomePage(driver);
        Assert.assertEquals(homePage.isDashBoardVisible(), "Dashboard");    
        homePage.checkPatientNameOnDashboard();
    }
	
	@Test
	public void isPatientNameSaved() throws InterruptedException {
		LoginPage loginPage = new LoginPage(driver);
        loginPage.login("test@kennect.io", "Qwerty@1234");

        HomePage homePage = new HomePage(driver);
        homePage.checkPatientNameOnDashboard();
	}
	
    
    
}
